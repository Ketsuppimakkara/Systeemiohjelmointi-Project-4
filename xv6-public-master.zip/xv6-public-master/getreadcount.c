#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
  int count;  
  printf(1,"Running system call...\n");
  if(argc > 1){                         //If the user wants to reset their counter, they'll give "reset" as an argument, but as you can see, giving any argument at all results in a reset.
      getreadcount(1);
      printf(1,"Read counter reset!\n");
  }
  else{
    count = getreadcount(0);
    printf(1,"System call completed! Number of read() system calls made: '%d'\n",count);
  }

  exit();
}